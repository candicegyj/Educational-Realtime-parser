package edu.bsu.cs222;

import org.junit.Assert;
import org.junit.Test;

public class SentenceTests {

    @Test
    public void sentenceWithDirectObjectTestSubject(){
        String testString = "Bob hit the ball";
        Sentence sentence = new Sentence(testString);
        String[] subject = sentence.getSubject();
        String[] knownSubject = new String[]{"Bob","Bobs"};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(subject, knownSubject));
    }

    @Test
    public void sentenceWithDirectObjectTestAction(){
        String testString = "Bob hit the ball";
        Sentence sentence = new Sentence(testString);
        String[] action = sentence.getAction();
        String[] knownAction = new String[]{"hit","hits","hitting"};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(action, knownAction));
    }

    @Test
    public void sentenceWithDirectObjectTestDirectObject(){
        String testString = "Bob hit the ball";
        Sentence sentence = new Sentence(testString);
        String[] directObject = sentence.getDirectObject();
        String[] knownDirectObject = new String[]{"ball","balls"};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(directObject, knownDirectObject));
    }

    @Test
    public void sentenceWithoutDirectObjectTestSubject(){
        String testString = "Bob slept";
        Sentence sentence = new Sentence(testString);
        String[] subject = sentence.getSubject();
        String[] knownSubject = new String[]{"Bob","Bobs"};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(subject, knownSubject));
    }

    @Test
    public void sentenceWithoutDirectObjectTestAction(){
        String testString = "Bob slept";
        Sentence sentence = new Sentence(testString);
        String[] action = sentence.getAction();
        String[] knownAction = new String[]{"sleep","sleeps","slept","sleeping"};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(action, knownAction));
    }


    @Test
    public void sentenceWithPrepositionsWithoutDirectObjectTestSubject(){
        String testString = "Bob slept at school";
        Sentence sentence = new Sentence(testString);
        String[] subject = sentence.getSubject();
        String[] knownSubject = new String[]{"Bob","Bobs"};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(subject, knownSubject));
    }

    @Test
    public void sentenceWithPrepositionsWithoutDirectObjectTestAction(){
        String testString = "Bob slept at school";
        Sentence sentence = new Sentence(testString);
        String[] action = sentence.getAction();
        String[] knownAction = new String[]{"sleep","sleeps","sleeping","slept"};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(action, knownAction));
    }

    @Test
    public void sentenceWithPrepositionsWithoutDirectObjectTestPreposition(){
        String testString = "Bob slept at school";
        Sentence sentence = new Sentence(testString);
        PrepositionalPhrase phrase = sentence.getPrepositionalPhrases()[0];
        PrepositionalPhrase knownPhrase = new PrepositionalPhrase(new String[]{"at", "school"});
        Assert.assertTrue(knownPhrase.equals(phrase));
    }

    @Test
    public void sentenceWithPrepositionsWithoutDirectObjectTestDirectObject(){
        String testString = "Bob slept at school";
        Sentence sentence = new Sentence(testString);
        String[] object = sentence.getDirectObject();
        String[] knownObject = new String[]{""};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(object, knownObject));
    }

    @Test
    public void sentenceWithPrepositionsWithDirectObjectTestDirectObject(){
        String testString = "Bob hit the ball to the moon";
        Sentence sentence = new Sentence(testString);
        String[] object = sentence.getDirectObject();
        String[] knownObject = new String[]{"ball","balls"};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(object, knownObject));
    }
}


