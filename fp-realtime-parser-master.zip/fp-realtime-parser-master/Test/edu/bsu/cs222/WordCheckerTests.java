package edu.bsu.cs222;

import org.junit.Assert;
import org.junit.Test;

public class WordCheckerTests {

    @Test
    public void trueArrayTest(){
        WordChecker wordChecker = new WordChecker();
        String[] testWord = new String[]{"Bob","Sue","John"};
        String[] knownWord = new String[]{"Bob", "Sue","John","Carl","arbitrarytest"};
        Assert.assertTrue(wordChecker.checkIfSameWord(testWord, knownWord));
    }

    @Test
    public void falseArrayTest(){
        WordChecker wordChecker = new WordChecker();
        String[] testWord = new String[]{"Bob","Sue","John","wrong"};
        String[] knownWord = new String[]{"Bob", "Sue","John","Carl","arbitrarytest"};
        Assert.assertFalse(wordChecker.checkIfSameWord(testWord, knownWord));
    }

    @Test
    public void falseArrayTestMissing(){
        WordChecker wordChecker = new WordChecker();
        String[] testWord = new String[]{"Bob","Sue","John"};
        String[] knownWord = new String[]{"Bob", "Sue","Carl","arbitrarytest"};
        Assert.assertFalse(wordChecker.checkIfSameWord(testWord, knownWord));
    }

    @Test
    public void trueStringTest(){
        WordChecker wordChecker = new WordChecker();
        String testWord = "Bob";
        String[] knownWord = new String[]{"Bob", "Sue","John","Carl","arbitrarytest"};
        Assert.assertTrue(wordChecker.checkIfSameWord(testWord, knownWord));
    }

    @Test
    public void falseStringTest(){
        WordChecker wordChecker = new WordChecker();
        String testWord = "wumbo";
        String[] knownWord = new String[]{"Bob", "Sue","John","Carl","arbitrarytest"};
        Assert.assertFalse(wordChecker.checkIfSameWord(testWord, knownWord));
    }
}
