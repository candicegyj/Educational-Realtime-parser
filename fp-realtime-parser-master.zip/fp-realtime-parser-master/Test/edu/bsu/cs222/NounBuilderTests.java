package edu.bsu.cs222;

import org.junit.Assert;
import org.junit.Test;

public class NounBuilderTests {

    @Test
    public void deerTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("Deer");
        String[] knownNoun = new String[]{"Deer"};
        Assert.assertTrue(wordChecker.checkIfSameWord(testNoun, knownNoun));
    }

    @Test
    public void symposiaTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("symposia");
        String[] knownNoun = new String[]{"symposium","symposia","symposiums"};
        Assert.assertTrue(wordChecker.checkIfSameWord(testNoun, knownNoun));
    }

    @Test
    public void colorTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("color");
        String[] knownNoun = new String[]{"color","colors"};
        Assert.assertTrue(wordChecker.checkIfSameWord(testNoun, knownNoun));
    }

    @Test
    public void colorsTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("colors");
        String[] knownNoun = new String[]{"color","colors"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void kissTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("kiss");
        String[] knownNoun = new String[]{"kiss","kisses"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void kissesTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("kisses");
        String[] knownNoun = new String[]{"kiss","kisses"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void quizTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("quiz");
        String[] knownNoun = new String[]{"quizzes","quiz"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void quizzesTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("quizzes");
        String[] knownNoun = new String[]{"quizzes","quiz"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void boxTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("box");
        String[] knownNoun = new String[]{"box","boxes"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void boxesTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("boxes");
        String[] knownNoun = new String[]{"box","boxes"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void matchTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("match");
        String[] knownNoun = new String[]{"matches","match"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void matchesTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("matches");
        String[] knownNoun = new String[]{"matches","match"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void fineTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("fine");
        String[] knownNoun = new String[]{"fine","fines"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void finesTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("fines");
        String[] knownNoun = new String[]{"fine","fines"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void cityTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("city");
        String[] knownNoun = new String[]{"city","cities"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void citiesTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("cities");
        String[] knownNoun = new String[]{"city","cities"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void gasTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("gas");
        String[] knownNoun = new String[]{"gas","gasses"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

    @Test
    public void gassesTest(){
        WordChecker wordChecker = new WordChecker();
        NounBuilder nounBuilder = new NounBuilder();
        String[] testNoun = nounBuilder.createNoun("gasses");
        String[] knownNoun = new String[]{"gas","gasses"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownNoun, testNoun));
    }

}
