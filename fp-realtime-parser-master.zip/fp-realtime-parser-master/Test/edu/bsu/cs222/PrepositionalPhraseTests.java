package edu.bsu.cs222;

import org.junit.Assert;
import org.junit.Test;

public class PrepositionalPhraseTests {
    @Test
    public void atSchoolSubjectTest(){
        String[] atSchool = new String[]{"at","school"};
        PrepositionalPhrase phrase = new PrepositionalPhrase(atSchool);
        String[] subject = new String[]{"school","schools"};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(phrase.getSubject(), subject));
    }

    @Test
    public void atSchoolPrepositionTest(){
        String[] atSchool = new String[]{"at","school"};
        PrepositionalPhrase phrase = new PrepositionalPhrase(atSchool);
        String preposition = "at";
        Assert.assertTrue(preposition.equalsIgnoreCase(phrase.getPreposition()));
    }

    @Test
    public void atTheSchoolSubjectTest(){
        String[] atSchool = new String[]{"at","the","school"};
        PrepositionalPhrase phrase = new PrepositionalPhrase(atSchool);
        String[] subject = new String[]{"school","schools"};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(phrase.getSubject(), subject));
    }

    @Test
    public void atTheSchoolPrepositionTest(){
        String[] atSchool = new String[]{"at","the","school"};
        PrepositionalPhrase phrase = new PrepositionalPhrase(atSchool);
        String preposition = "at";
        Assert.assertTrue(preposition.equalsIgnoreCase(phrase.getPreposition()));
    }

    @Test
    public void equalsTest(){
        String[] atSchool = new String[]{"at","the","school"};
        PrepositionalPhrase phrase1 = new PrepositionalPhrase(atSchool);
        String[] atTheSchool = new String[]{"at","the","school"};
        PrepositionalPhrase phrase2 = new PrepositionalPhrase(atTheSchool);
        Assert.assertTrue(phrase1.equals(phrase2));
    }

    @Test
    public void equalsFalsePrepositionTest(){
        String[] atSchool = new String[]{"at","the","school"};
        PrepositionalPhrase phrase1 = new PrepositionalPhrase(atSchool);
        String[] toSchool = new String[]{"to", "school"};
        PrepositionalPhrase phrase2 = new PrepositionalPhrase(toSchool);
        Assert.assertFalse(phrase1.equals(phrase2));
    }

    @Test
    public void equalsFalseNounTest(){
        String[] atSchool = new String[]{"at","the","school"};
        PrepositionalPhrase phrase1 = new PrepositionalPhrase(atSchool);
        String[] atHome = new String[]{"at", "home"};
        PrepositionalPhrase phrase2 = new PrepositionalPhrase(atHome);
        Assert.assertFalse(phrase1.equals(phrase2));
    }
}
