package edu.bsu.cs222;

import org.junit.Assert;
import org.junit.Test;

public class ParagraphParserTest {

    @Test
    public void splitParagraphTest() {
        String test = "The Cat ran. He hit a wall.";
        ParagraphParser paragraphParser = new ParagraphParser();
        Sentence[] sentences = paragraphParser.parseParagraph(test);
        System.out.println(sentences[0]);
        Assert.assertEquals("The Cat ran.", sentences[0].getSentence());
    }

    @Test
    public void splitParagraphTest2() {
        String test = "The Cat ran. He hit a wall. He ran to fast.";
        ParagraphParser paragraphParser = new ParagraphParser();
        Sentence[] sentences = paragraphParser.parseParagraph(test);
        System.out.println(sentences[2]);
        Assert.assertEquals("He hit a wall.", sentences[1].getSentence());
    }

}
