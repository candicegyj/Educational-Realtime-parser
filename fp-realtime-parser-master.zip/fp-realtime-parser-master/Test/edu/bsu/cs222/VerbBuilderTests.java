package edu.bsu.cs222;

import org.junit.Assert;
import org.junit.Test;

public class VerbBuilderTests {

    @Test
    public void beTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("is");
        String[] knownVerb = new String[]{"be","am","is","are","were","was","been","being"};
        Assert.assertTrue(wordChecker.checkIfSameWord(testVerb, knownVerb));
    }

    @Test
    public void writeTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("wrote");
        String[] knownVerb = new String[]{"write", "writes","wrote","written","writing"};
        Assert.assertTrue(wordChecker.checkIfSameWord(testVerb, knownVerb));
    }

    @Test
    public void workTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("work");
        String[] knownVerb = new String[]{"work","works","worked","working"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void worksTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("works");
        String[] knownVerb = new String[]{"work","works","worked","working"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void workedTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("worked");
        String[] knownVerb = new String[]{"work","works","worked","working"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void workingTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("working");
        String[] knownVerb = new String[]{"work","works","worked","working"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void complyTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("comply");
        String[] knownVerb = new String[]{"comply","complies","complied","complying"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void compliesTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("complies");
        String[] knownVerb = new String[]{"comply","complies","complied","complying"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void compliedTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("complied");
        String[] knownVerb = new String[]{"comply","complies","complied","complying"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void complyingTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("complying");
        String[] knownVerb = new String[]{"comply","complies","complied","complying"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void dineTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("dine");
        String[] knownVerb = new String[]{"dine","dines","dined","dining"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void dinesTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("dines");
        String[] knownVerb = new String[]{"dine","dines","dined","dining"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void dinedTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("dined");
        String[] knownVerb = new String[]{"dine","dines","dined","dining"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void diningTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("dining");
        String[] knownVerb = new String[]{"dine","dines","dined","dining"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void watchTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("watch");
        String[] knownVerb = new String[]{"watch","watched","watches","watching"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void watchesTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("watches");
        String[] knownVerb = new String[]{"watch","watched","watches","watching"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void watchedTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("watched");
        String[] knownVerb = new String[]{"watch","watched","watches","watching"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

    @Test
    public void watchingTest(){
        WordChecker wordChecker = new WordChecker();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] testVerb = verbBuilder.createVerb("watching");
        String[] knownVerb = new String[]{"watch","watched","watches","watching"};
        Assert.assertTrue(wordChecker.checkIfSameWord(knownVerb, testVerb));
    }

}
