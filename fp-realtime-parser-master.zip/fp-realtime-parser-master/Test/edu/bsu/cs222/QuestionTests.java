package edu.bsu.cs222;

import org.junit.Assert;
import org.junit.Test;

public class QuestionTests {
    @Test
    public void whatWithoutDirectObjectSubjectTest(){
        String sentence = "What did the cat do";
        Question question = new Question(sentence);
        String[] subject = question.getSubject();
        NounBuilder nounBuilder = new NounBuilder();
        String[] knownSubject = nounBuilder.createNoun("cat");
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(subject, knownSubject));
    }

    @Test
    public void whatWithoutDirectObjectActionTest(){
        String sentence = "What did the cat do";
        Question question = new Question(sentence);
        String[] action = question.getAction();
        String[] knownAction = new String[]{""};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(action, knownAction));
    }

    @Test
    public void whatWithoutDirectObjectDirectObjectTest(){
        String sentence = "What did the cat do";
        Question question = new Question(sentence);
        String[] directObject = question.getDirectObject();
        String[] knownDirectObject = new String[]{""};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(directObject, knownDirectObject));
    }

    @Test
    public void whatWithoutDirectObjectQuestionTypeTest(){
        String sentence = "What did the cat do";
        Question question = new Question(sentence);
        String questionType = question.getQuestionType();
        String knownQuestionType = "action";
        Assert.assertEquals(questionType, knownQuestionType);
    }

    @Test
    public void whatWithDirectObjectSubjectTest(){
        String sentence = "What did the cat do to Bob";
        Question question = new Question(sentence);
        String[] subject = question.getSubject();
        NounBuilder nounBuilder = new NounBuilder();
        String[] knownSubject = nounBuilder.createNoun("cat");
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(subject, knownSubject));
    }

    @Test
    public void whatWithDirectObjectActionTest(){
        String sentence = "What did the cat do to Bob";
        Question question = new Question(sentence);
        String[] action = question.getAction();
        String[] knownAction = new String[]{""};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(action, knownAction));
    }

    @Test
    public void whatWithDirectObjectDirectObjectTest(){
        String sentence = "What did the cat do to Bob";
        Question question = new Question(sentence);
        String[] directObject = question.getDirectObject();
        NounBuilder nounBuilder = new NounBuilder();
        String[] knownDirectObject = nounBuilder.createNoun("Bob");
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(directObject, knownDirectObject));
    }

    @Test
    public void whatWithDirectObjectQuestionTypeTest(){
        String sentence = "What did the cat do to Bob";
        Question question = new Question(sentence);
        String questionType = question.getQuestionType();
        String knownQuestionType = "action";
        Assert.assertEquals(questionType, knownQuestionType);
    }

    @Test
    public void whatWhoEquivalentSubjectTest(){
        String sentence = "What person did the cat hit";
        Question question = new Question(sentence);
        String[] subject = question.getSubject();
        NounBuilder nounBuilder = new NounBuilder();
        String[] knownSubject = nounBuilder.createNoun("cat");
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(subject, knownSubject));
    }

    @Test
    public void whatWhoEquivalentActionTest(){
        String sentence = "What person did the cat hit";
        Question question = new Question(sentence);
        String[] action = question.getAction();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] knownAction = verbBuilder.createVerb("hit");
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(action, knownAction));
    }

    @Test
    public void whatWhoEquivalentDirectObjectTest(){
        String sentence = "What person did the cat hit";
        Question question = new Question(sentence);
        String[] directObject = question.getDirectObject();
        String[] knownDirectObject = new String[]{""};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(directObject, knownDirectObject));
    }

    @Test
    public void whatWhoEquivalentQuestionTypeTest(){
        String sentence = "What person did the cat hit";
        Question question = new Question(sentence);
        String questionType = question.getQuestionType();
        String knownQuestionType = "direct object";
        Assert.assertEquals(questionType, knownQuestionType);
    }

    @Test
    public void whoSubjectQuestionWithoutDirectObjectSubjectTest(){
        String sentence = "Who hit";
        Question question = new Question(sentence);
        String[] subject = question.getSubject();
        String[] knownSubject = new String[]{""};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(subject, knownSubject));
    }

    @Test
    public void whoSubjectQuestionWithoutDirectObjectActionTest(){
        String sentence = "Who hit";
        Question question = new Question(sentence);
        String[] action = question.getAction();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] knownAction = verbBuilder.createVerb("hit");
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(action, knownAction));
    }

    @Test
    public void whoSubjectQuestionWithoutDirectObjectDirectObjectTest(){
        String sentence = "Who hit";
        Question question = new Question(sentence);
        String[] directObject = question.getDirectObject();
        String[] knownDirectObject = new String[]{""};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(directObject, knownDirectObject));
    }

    @Test
    public void whoSubjectQuestionWithoutDirectObjectQuestionTypeTest(){
        String sentence = "Who hit";
        Question question = new Question(sentence);
        String questionType = question.getQuestionType();
        String knownQuestionType = "subject";
        Assert.assertEquals(questionType, knownQuestionType);
    }

    @Test
    public void whoSubjectQuestionWithDirectObjectSubjectTest(){
        String sentence = "Who hit Bob";
        Question question = new Question(sentence);
        String[] subject = question.getSubject();
        String[] knownSubject = new String[]{""};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(subject, knownSubject));
    }

    @Test
    public void whoSubjectQuestionWithDirectObjectActionTest(){
        String sentence = "Who hit Bob";
        Question question = new Question(sentence);
        String[] action = question.getAction();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] knownAction = verbBuilder.createVerb("hit");
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(action, knownAction));
    }

    @Test
    public void whoSubjectQuestionWithDirectObjectDirectObjectTest(){
        String sentence = "Who hit Bob";
        Question question = new Question(sentence);
        String[] directObject = question.getDirectObject();
        NounBuilder nounBuilder = new NounBuilder();
        String[] knownDirectObject = nounBuilder.createNoun("Bob");
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(directObject, knownDirectObject));
    }

    @Test
    public void whoSubjectQuestionWithDirectObjectQuestionTypeTest(){
        String sentence = "Who hit Bob";
        Question question = new Question(sentence);
        String questionType = question.getQuestionType();
        String knownQuestionType = "subject";
        Assert.assertEquals(questionType, knownQuestionType);
    }

    @Test
    public void whoDirectObjectQuestionSubjectTest(){
        String sentence = "Who did the cat hit";
        Question question = new Question(sentence);
        String[] subject = question.getSubject();
        NounBuilder nounBuilder = new NounBuilder();
        String[] knownSubject = nounBuilder.createNoun("cat");
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(subject, knownSubject));
    }

    @Test
    public void whoDirectObjectQuestionActionTest(){
        String sentence = "Who did the cat hit";
        Question question = new Question(sentence);
        String[] action = question.getAction();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] knownAction = verbBuilder.createVerb("hit");
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(action, knownAction));
    }

    @Test
    public void whoDirectObjectQuestionDirectObjectTest(){
        String sentence = "Who did the cat hit";
        Question question = new Question(sentence);
        String[] directObject = question.getDirectObject();
        String[] knownDirectObject = new String[]{""};
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(directObject, knownDirectObject));
    }

    @Test
    public void whoDirectObjectQuestionQuestionTypeTest(){
        String sentence = "Who did the cat hit";
        Question question = new Question(sentence);
        String questionType = question.getQuestionType();
        String knownQuestionType = "direct object";
        Assert.assertEquals(questionType, knownQuestionType);
    }

    @Test
    public void yesOrNoQuestionSubjectTest(){
        String sentence = "Did the cat hit Bob";
        Question question = new Question(sentence);
        String[] subject = question.getSubject();
        NounBuilder nounBuilder = new NounBuilder();
        String[] knownSubject = nounBuilder.createNoun("cat");
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(subject, knownSubject));
    }

    @Test
    public void yesOrNoQuestionActionTest(){
        String sentence = "Did the cat hit Bob";
        Question question = new Question(sentence);
        String[] action = question.getAction();
        VerbBuilder verbBuilder = new VerbBuilder();
        String[] knownAction = verbBuilder.createVerb("hit");
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(action, knownAction));
    }

    @Test
    public void yesOrNoQuestionDirectObjectTest(){
        String sentence = "Did the cat hit Bob";
        Question question = new Question(sentence);
        String[] directObject = question.getDirectObject();
        NounBuilder nounBuilder = new NounBuilder();
        String[] knownDirectObject = nounBuilder.createNoun("Bob");
        WordChecker wordChecker = new WordChecker();
        Assert.assertTrue(wordChecker.checkIfSameWord(directObject, knownDirectObject));
    }


    @Test
    public void yesOrNoQuestionQuestionTypeTest(){
        String sentence = "Did the cat hit Bob";
        Question question = new Question(sentence);
        String questionType = question.getQuestionType();
        String knownQuestionType = "yes or no";
        Assert.assertEquals(questionType, knownQuestionType);
    }

}
