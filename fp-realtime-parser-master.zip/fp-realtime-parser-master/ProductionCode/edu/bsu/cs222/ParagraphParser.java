package edu.bsu.cs222;

public class ParagraphParser {
    public Sentence[] parseParagraph(String paragraph) {
        String[] stringSentencesInit = paragraph.split("(?<=[.!])\\s* ");
        String[] stringSentences = new String[stringSentencesInit.length];

        for (int i = 0; i<stringSentencesInit.length; i++) {
            stringSentences[i] = stringSentencesInit[i];
        }

        Sentence[] objectSentences = new Sentence[stringSentences.length];

        for (int i = 0; i<stringSentences.length; i++) {
            objectSentences[i] = new Sentence(stringSentences[i].trim());
        }

        return objectSentences;
    }
}
