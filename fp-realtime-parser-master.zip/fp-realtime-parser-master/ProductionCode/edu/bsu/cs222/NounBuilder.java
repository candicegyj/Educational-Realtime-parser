package edu.bsu.cs222;

public class NounBuilder {

    private String[][] irregularNouns;

    public NounBuilder(){
        irregularNouns = createIrregularNouns();
    }

    private String[][] createIrregularNouns() {
        String[][] nouns = new String[118][3];
        //irregular nouns are separated in the code into paragraphs based on the first letter of the base form of the noun
        nouns[0] = new String[]{"addendum","addenda"};
        nouns[1] = new String[]{"alga", "algae"};
        nouns[2] = new String[]{"alumna", "alumnae"};
        nouns[3] = new String[]{"alumnus", "alumni"};
        nouns[4] = new String[]{"analysis","analyses"};
        nouns[5] = new String[]{"antenna","antennas","antennae"};
        nouns[6] = new String[]{"apparatus", "apparatuses"};
        nouns[7] = new String[]{"appendix","appendices","appendixes"};
        nouns[8] = new String[]{"axis","axes"};

        nouns[9] = new String[]{"bacillus", "bacilli"};
        nouns[10] = new String[]{"bacterium", "bacteria"};
        nouns[12] = new String[]{"beau", "beaux"};
        nouns[13] = new String[]{"bison"};
        nouns[14] = new String[]{"buffalo","buffalos","buffaloes"};
        nouns[15] = new String[]{"bureau", "bureaus"};
        nouns[16] = new String[]{"bus","busses","buses"};

        nouns[17] = new String[]{"cactus", "cactuses", "cacti"};
        nouns[18] = new String[]{"calf", "calves"};
        nouns[19] = new String[]{"child","children"};
        nouns[20] = new String[]{"corps"};
        nouns[21] = new String[]{"corpus", "corpora", "corpuses"};
        nouns[22] = new String[]{"crisis", "crises"};
        nouns[23] = new String[]{"criterion", "criteria"};
        nouns[24] = new String[]{"curriculum", "curricula"};

        nouns[25] = new String[]{"datum","data"};
        nouns[26] = new String[]{"deer"};
        nouns[27] = new String[]{"die","dice"};
        nouns[28] = new String[]{"dwarf","dwarfs","dwarves"};
        nouns[29] = new String[]{"diagnosis","diagnoses"};

        nouns[30] = new String[]{"echo","echoes"};
        nouns[31] = new String[]{"elf","elves"};
        nouns[32] = new String[]{"ellipsis","ellipses"};
        nouns[33] = new String[]{"embargo", "embargoes"};
        nouns[34] = new String[]{"emphasis","emphases"};
        nouns[35] = new String[]{"erratum", "errata"};

        nouns[36] = new String[]{"fireman", "firemen"};
        nouns[37] = new String[]{"fish", "fishes"};
        nouns[38] = new String[]{"focus", "focuses"};
        nouns[39] = new String[]{"foot","feet"};
        nouns[40] = new String[]{"formula","formulas"};
        nouns[41] = new String[]{"fungus", "fungi","funguses"};

        nouns[42] = new String[]{"genus", "genera"};
        nouns[43] = new String[]{"goose", "geese"};

        nouns[44] = new String[]{"half", "halves"};
        nouns[45] = new String[]{"hero","heroes"};
        nouns[46] = new String[]{"hippopotamus","hippopotami","hippopotamuses"};
        nouns[47] = new String[]{"hoof", "hoofs", "hooves"};
        nouns[48] = new String[]{"hypothesis", "hypotheses"};

        nouns[49] = new String[]{"index", "indices","indexes"};

        nouns[50] = new String[]{"knife","knives"};

        nouns[51] = new String[]{"leaf", "leaves"};
        nouns[52] = new String[]{"life","lives"};
        nouns[53] = new String[]{"loaf", "loaves"};
        nouns[54] = new String[]{"louse","lice"};

        nouns[55] = new String[]{"man", "men"};
        nouns[56] = new String[]{"matrix","matrices"};
        nouns[57] = new String[]{"means"};
        nouns[58] = new String[]{"medium", "media"};
        nouns[59] = new String[]{"memorandum","memoranda"};
        nouns[60] = new String[]{"millennium", "millenniums","millennia"};
        nouns[61] = new String[]{"moose"};
        nouns[62] = new String[]{"mosquito","mosquitoes"};
        nouns[63] = new String[]{"mouse","mice"};

        nouns[64] = new String[]{"nebula","nebulae","nebulas"};
        nouns[65] = new String[]{"neurosis","neuroses"};
        nouns[66] = new String[]{"nucleus","nuclei"};

        nouns[67] = new String[]{"oasis","oases"};
        nouns[68] = new String[]{"octopus","octopi","octopuses"};
        nouns[69] = new String[]{"ovum","ova"};
        nouns[70] = new String[]{"ox","oxen"};

        nouns[71] = new String[]{"paralysis","paralyses"};
        nouns[72] = new String[]{"parenthesis","parentheses"};
        nouns[73] = new String[]{"person","people"};
        nouns[74] = new String[]{"phenomenon","phenomena"};
        nouns[75] = new String[]{"potato","potatoes"};

        nouns[76] = new String[]{"radius","radii","radiuses"};

        nouns[77] = new String[]{"scarf","scarfs","scarves"};
        nouns[78] = new String[]{"self","selves"};
        nouns[79] = new String[]{"series"};
        nouns[80] = new String[]{"sheep"};
        nouns[81] = new String[]{"shelf","shelves"};
        nouns[82] = new String[]{"scissors"};
        nouns[83] = new String[]{"species"};
        nouns[84] = new String[]{"stimulus","stimuli"};
        nouns[85] = new String[]{"stratum","strata"};
        nouns[86] = new String[]{"syllabus","syllabi","syllabuses"};
        nouns[87] = new String[]{"symposium","symposia","symposiums"};
        nouns[88] = new String[]{"synthesis","syntheses"};
        nouns[89] = new String[]{"synopsis","synopses"};

        nouns[90] = new String[]{"tableau","tableaux"};
        nouns[91] = new String[]{"that","those"};
        nouns[92] = new String[]{"thesis","theses"};
        nouns[93] = new String[]{"thief","thieves"};
        nouns[94] = new String[]{"this","these"};
        nouns[95] = new String[]{"tomato","tomatoes"};
        nouns[96] = new String[]{"tooth","teeth"};
        nouns[97] = new String[]{"torpedo","torpedoes"};

        nouns[98] = new String[]{"vertebra","vertebrae"};
        nouns[99] = new String[]{"veto","vetoes"};
        nouns[100] = new String[]{"vita","vitae"};

        nouns[101] = new String[]{"watch","watches"};
        nouns[102] = new String[]{"wife","wives"};
        nouns[103] = new String[]{"wolf","wolves"};
        nouns[104] = new String[]{"woman","women"};

        nouns[105] = new String[]{"zero","zeros","zeroes"};

        //Pronouns
        nouns[106] = new String[]{"I"};
        nouns[107] = new String[]{"he"};
        nouns[108] = new String[]{"she"};
        nouns[109] = new String[]{"it"};
        nouns[110] = new String[]{"they"};
        nouns[111] = new String[]{"you"};
        nouns[112] = new String[]{"her"};
        nouns[113] = new String[]{"him"};
        nouns[114] = new String[]{"we"};
        nouns[115] = new String[]{"us"};
        nouns[116] = new String[]{"them"};
        nouns[117] = new String[]{"me"};

        return nouns;
    }

    public String[] createNoun(String word){
        if(word.equals("")){
            return new String[]{""};
        }
        for(String[] irregularNoun : irregularNouns){
            for(String form : irregularNoun){
                if(word.equalsIgnoreCase(form)){
                    return irregularNoun;
                }
            }
        }
        return createRegularNoun(word);
    }

    private String[] createRegularNoun(String word) {
        int length = word.length();
        if(word.endsWith("sses")){
            return new String[]{word, word.substring(0,length-2),word.substring(0,length-3)};
        }
        if(word.endsWith("ss")||word.endsWith("sh")||word.endsWith("ch")||word.endsWith("x")){
            return new String[]{word, word+"es"};
        }
        if(word.endsWith("ies")){
            return new String[]{word, word.substring(0,length-3)+"y", word.substring(0, length-1)};
        }
        if(word.endsWith("zzes")){
            return new String[]{word, word.substring(0,length-2), word.substring(0,length-3)};
        }
        if(word.endsWith("es")){
            return new String[]{word, word.substring(0,length-1), word.substring(0, length-2)};
        }
        if(word.endsWith("s")){
            return new String[]{word, word+"es", word.substring(0,length-1), word+"ses"};
        }
        if(word.endsWith("z")){
            return new String[]{word, word+"es", word+"zes"};
        }
        if(word.endsWith("y") && checkIfConsonant(word.charAt(length-1))){
            return new String[]{word, word.substring(0,length-1)+"ies"};
        }
        return new String[]{word, word+"s"};
    }

    private boolean checkIfConsonant(char letter) {
        return !(letter=='a'||letter=='e'||letter=='i'||letter=='o'||letter=='u');
    }
}