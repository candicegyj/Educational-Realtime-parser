package edu.bsu.cs222;

public class SentenceParser {


    public String[] parseSentence(String sentence) {
        sentence = sentence.trim();
        String[] splitSentence = sentence.split(" ");
        return createOutput(splitSentence);
    }

    private String[] createOutput(String[] splitSentence) {
        String[] outputWords = new String[3];
        int count = 0;
        for(String word : splitSentence) {
            if (!(word.equalsIgnoreCase("the") || word.equalsIgnoreCase("a") || word.equalsIgnoreCase("an"))) {
                outputWords[count] = word;
                count++;
            }
        }
        if(count==2){
            outputWords[2] = "";
        }
        return outputWords;
    }
}