package edu.bsu.cs222;

public class PrepositionalPhrase {

    private String preposition;
    private String[] subject;

    public PrepositionalPhrase(String[] phrase){
        preposition = phrase[0];
        NounBuilder nounBuilder = new NounBuilder();
        for(int i =1;i<phrase.length; i++) {
            if (!(phrase[i].equalsIgnoreCase("the")||phrase[i].equalsIgnoreCase("a")||phrase[i].equalsIgnoreCase("an"))) {
                subject = nounBuilder.createNoun(phrase[i]);
            }
        }
    }

    public String getPreposition(){
        return preposition;
    }

    public String[] getSubject(){
        return subject;
    }

    public boolean equals(PrepositionalPhrase other){
        WordChecker wordChecker = new WordChecker();
        return preposition.equals(other.getPreposition()) && wordChecker.checkIfSameWord(subject, other.getSubject());
    }

    public String toString(){
        return preposition + subject[0];
    }
}
