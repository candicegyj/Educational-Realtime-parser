package edu.bsu.cs222;

import javafx.application.Application;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class Gui extends Application {
    private static final TextArea textArea = new TextArea();
    private static TreeTableView<String> table;
    private static final HBox hbox = new HBox();

    public static void main(String[] args) { Application.launch(Gui.class, args); }

    @Override
    public void start(Stage stage) {

        setupStage(stage);
        final Scene scene = new Scene(new Group(), 512, 288);
        Group sceneRoot = (Group)scene.getRoot();
        try {
            FileUtils.createFile("rightFile.txt");
            FileUtils.createFile("leftFile.txt");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        textArea.setPrefHeight(504);
        textArea.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.PERIOD)
                updateData();
        });

        hbox.setSpacing(4);
        hbox.getChildren().addAll(textArea);
        Button button = new Button("History");
        button.setPrefSize(100, 20);
        button.setOnAction(oa->{
            new AlertBox().display("ok!ʷ", getFileContent());
        });
        button.setLayoutX(button.getLayoutX()-100);
        hbox.getChildren().add(button);

        sceneRoot.getChildren().addAll(hbox);


        stage.setScene(scene);

        stage.show();
    }

    private static String getFileContent(){
        String content = "";
        String left = "left content：\n"+FileUtils.txt2String("leftFile.txt");
        String right = "right content：\n"+FileUtils.txt2String("rightFile.txt");
        content+=left
                +"\n--------" +
                "-----------------------\n\n"
                +right;
        return content;
    }

    private static void updateData()
    {


        //remove old table
        hbox.getChildren().remove(table);

        //create column
        TreeTableColumn<String,String> column = new TreeTableColumn<>("Sentences");
        column.setPrefWidth(500);

        //define cell content
        column.setCellValueFactory((TreeTableColumn.CellDataFeatures<String, String> p) ->
                new ReadOnlyStringWrapper(p.getValue().getValue()));

        ParagraphParser pParser = new ParagraphParser();
        Sentence[] sentences = pParser.parseParagraph(textArea.getText());
        String [] leftStr = textArea.getText().split("\n");
        FileUtils.contentToTxt("leftFile.txt", leftStr[leftStr.length-1]+".\n");
        final TreeItem<String> root = new TreeItem<>("Sentences");
        root.setExpanded(true);
        String rightStr="";
        for(int i=0; i<sentences.length;i++){
            final TreeItem<String> sentenceRoot = new TreeItem<>(sentences[i].getSentence());
            sentenceRoot.setExpanded(true);
            root.getChildren().add(sentenceRoot);

            final TreeItem<String> childNode1 = new TreeItem<>("Subject: " + sentences[i].getSubject()[0]);
            final TreeItem<String> childNode2 = new TreeItem<>("Action: " + sentences[i].getAction()[0]);
            final TreeItem<String> childNode3 = new TreeItem<>("Direct Object: " + sentences[i].getDirectObject()[0]);
            if(i==(sentences.length-1)){
                rightStr+="Subject: " + sentences[i].getSubject()[0]+"\n"
                        +"Action: " + sentences[i].getAction()[0]+"\n"
                        +"Direct Object: " + sentences[i].getDirectObject()[0]+"\n";
            }

            sentenceRoot.getChildren().setAll(childNode1, childNode2, childNode3);
        }
        FileUtils.contentToTxt("rightFile.txt", rightStr+"\n");
        System.out.println("right content:"+rightStr+"\n");
        final TreeTableView<String> treeTableView = new TreeTableView<>(root);
        treeTableView.getColumns().add(column);
        treeTableView.setShowRoot(true);
        treeTableView.setPrefHeight(500);
        treeTableView.setPrefWidth(500);
        hbox.getChildren().add(treeTableView);

        table = treeTableView;
    }

    private void setupStage(Stage stage) {
        stage.setTitle("Educational Real-Time Sentence Parser");
        stage.setWidth(1024);
        stage.setHeight(512);
        stage.setResizable(false);
    }
}