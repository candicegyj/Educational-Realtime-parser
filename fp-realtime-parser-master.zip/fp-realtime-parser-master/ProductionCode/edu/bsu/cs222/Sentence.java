package edu.bsu.cs222;

public class Sentence {

    private String[] subject;
    private String[] action;
    private String[] directObject;
    private String sentence;
    private PrepositionalPhrase[] prepositionalPhrases;
    private String[] knownPrepositions;

    public Sentence(){
        sentence = "";
        subject = new String[]{""};
        action = new String[]{""};
        directObject = new String[]{""};
    }

    public Sentence(String sentence){
        this.sentence = sentence;
        knownPrepositions = new String[]{"with", "at", "from", "into", "during", "including", "until", "against","among","throughout","despite","towards", "upon","to","in","for","on","by","about","like","through","over","before","between","after","since","without","under","within","along","following","across","behind","beyond","plus","except","but","up","out","around","down","off","above","near"};
        int numberOfPrepositionalPhrases = 0;
        String[] words = sentence.split(" ");
        prepositionalPhrases = new PrepositionalPhrase[50];
        int wordTypeCount = 0;
        NounBuilder nounBuilder = new NounBuilder();
        VerbBuilder verbBuilder = new VerbBuilder();

        //This may not run through all of the values
        for(int i = 0; i<words.length; i++){
            String word = words[i];
            if(!(word.equalsIgnoreCase("the")||word.equalsIgnoreCase("a")||word.equalsIgnoreCase("an"))){
                //Finds and creates prepositional phrases
                for(String preposition: knownPrepositions) {
                    if (word.equalsIgnoreCase(preposition)) {
                        int prepositionalPhraseWordCount = 0;
                        String phrase[] = new String[2];
                        while (prepositionalPhraseWordCount <=1) {
                            if (word.equalsIgnoreCase("the") || word.equalsIgnoreCase("a") || word.equalsIgnoreCase("an")) {
                                i++;
                                word = words[i];
                            } else {
                                phrase[prepositionalPhraseWordCount] = word;
                                i++;
                                if(i<words.length) {
                                    word = words[i];
                                }
                                prepositionalPhraseWordCount++;
                            }
                        }
                        prepositionalPhrases[numberOfPrepositionalPhrases] = new PrepositionalPhrase(phrase);
                        numberOfPrepositionalPhrases++;
                    }
                }
                if(wordTypeCount==0){
                    subject = nounBuilder.createNoun(word);
                    wordTypeCount++;
                }
                else if(wordTypeCount==1){
                    action = verbBuilder.createVerb(word);
                    wordTypeCount++;
                }
                else if(wordTypeCount==2 && i < words.length){
                    directObject = nounBuilder.createNoun(word);
                    wordTypeCount++;
                }
            }
        }
        if(wordTypeCount==2){
            directObject = new String[]{""};
            wordTypeCount++;
        }
    }

    public String[] getSubject(){
        return subject;
    }

    public String[] getAction(){
        return action;
    }

    public String[] getDirectObject(){
        return directObject;
    }

    public String getSentence() { return sentence; }

    public PrepositionalPhrase[] getPrepositionalPhrases(){return prepositionalPhrases; }

    public void setSubject(String[] newSubject){ subject = newSubject; }

    public void setAction(String[] newAction){ action = newAction; }

    public void setDirectObject(String[] newDirectObject){ directObject = newDirectObject; }

    public boolean equals(Sentence other){
        WordChecker wordChecker = new WordChecker();
        return wordChecker.checkIfSameWord(subject, other.getSubject()) && wordChecker.checkIfSameWord(action, other.getAction()) && wordChecker.checkIfSameWord(directObject, other.getDirectObject());
    }

    public String toString(){
        return "Sentence: " + sentence + "\nSubject: " + subject[0] + "\nAction: " + action[0] + "\nDirect Object: " + directObject[0];
    }
}