package edu.bsu.cs222;

public class WordChecker {
    //testWord cannot contain verb forms that are not in knownWord if this is to evaluate to true, but knownWord can contain word forms that aren't in testWord
    public boolean checkIfSameWord(String[] testWord, String[] knownWord){
        if(testWord.length==1){
            if(knownWord.length==1){
                if(knownWord[0].equalsIgnoreCase("")){
                    return "".equalsIgnoreCase(testWord[0]);
                }
            }
        }
        for(String testForm : testWord){
            boolean test = false;
            for(String knownForm : knownWord){
              if(testForm.equalsIgnoreCase(knownForm)){
                   test = true;
                }
            }
            if(test==false){
                return false;
           }
        }
        return true;
    }

    public boolean checkIfSameWord(String testWord, String[] knownWord){
        for(String knownForm : knownWord){
            if(testWord.equalsIgnoreCase(knownForm)){
                return true;
            }
        }
        return false;
    }

}