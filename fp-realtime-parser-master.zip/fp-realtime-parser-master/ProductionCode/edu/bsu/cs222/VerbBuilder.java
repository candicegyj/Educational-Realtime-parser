package edu.bsu.cs222;

public class VerbBuilder {

    private String[][] irregularVerbs;

    public VerbBuilder(){
        irregularVerbs = createIrregularVerbs();
    }

    private String[][] createIrregularVerbs() {
        String[][] verbs = new String[187][8];
        //irregular verbs are separated in the code into paragraphs based on the first letter of the base form of the verb
        verbs[0] = new String[]{"alight", "alights", "alighted", "alit","alighting"};
        verbs[1] = new String[]{"arise", "arises","arose","arisen","arising"};
        verbs[2] = new String[]{"awake","awakes","awoke", "awaked", "awoken","awaking"};

        verbs[3] = new String[]{"be","am","is","are","were","was","been","being"};
        verbs[4] = new String[]{"bear", "bears", "bore", "borne","born","bearing"};
        verbs[5] = new String[]{"beat", "beats","beaten","beating"};
        verbs[6] = new String[]{"become","becomes", "became","becoming"};
        verbs[7] = new String[]{"beget","begets","begot","begotten","begetting"};
        verbs[8] = new String[]{"begin","begins", "began","begun","beginning"};
        verbs[9] = new String[]{"bend","bends","bent","bending"};
        verbs[10] = new String[]{"bereave","bereaves","bereaved","bereft","bereaving"};
        verbs[11] = new String[]{"beseech", "beseeches", "besought", "beseeched","beseeching"};
        verbs[12] = new String[]{"bet","bets", "betted","betting"};
        verbs[13] = new String[]{"bid", "bids", "bidden","bidding"};
        verbs[14] = new String[]{"bide","bides","bade","bided","biding"};
        verbs[15] = new String[]{"bind", "binds", "bound","binding"};
        verbs[16] = new String[]{"bite", "bites", "bitten","bit","biting"};
        verbs[17] = new String[]{"bleed","bleeds","bled","bleeding"};
        verbs[18] = new String[]{"bless","blesses","blessed","blest","blessing"};
        verbs[19] = new String[]{"blow","blows", "blew","blown","blowing"};
        verbs[20] = new String[]{"break","breaks","broke","broken","breaking"};
        verbs[21] = new String[]{"breed","breeds","bred","breeding"};
        verbs[22] = new String[]{"bring", "brings", "brought","bringing"};
        verbs[23] = new String[]{"broadcast", "broadcasts", "broadcasted","broadcasting"};
        verbs[24] = new String[]{"build","builds","built","building"};
        verbs[25] = new String[]{"burn","burns","burnt", "burned","burning"};
        verbs[26] = new String[]{"burst", "bursts","bursting"};
        verbs[27] = new String[]{"bust","busts","busted","busting"};
        verbs[28] = new String[]{"buy","buys","bought","buying"};

        verbs[29] = new String[]{"can","could"};
        verbs[30] = new String[]{"cast", "casts","casting"};
        verbs[31] = new String[]{"catch","catches","caught","catching"};
        verbs[32] = new String[]{"choose","chooses","chosen", "chose","choosing"};
        verbs[33] = new String[]{"cleave","cleaves","cleft","cleaved","clove","cloven"};
        verbs[34] = new String[]{"cling","clings","clung","clinging"};
        verbs[35] = new String[]{"clothe","clothes","clothed","clad","clothing"};
        verbs[36] = new String[]{"come","comes","came","coming"};
        verbs[37] = new String[]{"cost","costs","costing"};
        verbs[38] = new String[]{"creep","creeps","crept","creeping"};
        verbs[39] = new String[]{"crow","crows","crowed","crew","crowing"};
        verbs[40] = new String[]{"cut", "cuts","cutting"};

        verbs[41] = new String[]{"deal","deals","dealt","dealing"};
        verbs[42] = new String[]{"dig","digs", "dug","digging"};
        verbs[43] = new String[]{"do","does","did","done","doing"};
        verbs[44] = new String[]{"draw","draws","drew","drawn","drawing"};
        verbs[45] = new String[]{"dream","dreams","dreamt","dreamed","dreaming"};
        verbs[46] = new String[]{"drink","drinks","drank","drunk","drinking"};
        verbs[47] = new String[]{"drive","drives","drove","driven","driving"};
        verbs[48] = new String[]{"dwell","dwells","dwelt","dwelled","dwelling"};

        verbs[49] = new String[]{"eat","eats","ate","eaten","eating"};

        verbs[50] = new String[]{"fall","falls","fell","fallen","falling"};
        verbs[51] = new String[]{"feed","feeds","fed","feeding"};
        verbs[52] = new String[]{"feel","feels","felt","feeling"};
        verbs[53] = new String[]{"fight","fights","fought","fighting"};
        verbs[54] = new String[]{"find","finds","found","finding"};
        verbs[55] = new String[]{"flee","flees","fled","fleeing"};
        verbs[56] = new String[]{"fling","flings","flung","flinging"};
        verbs[57] = new String[]{"fly","flies","flew","flown","flying"};
        verbs[58] = new String[]{"forbid","forbids","forbad","forbade","forbidden","forbidding"};
        verbs[59] = new String[]{"forecast","forecasts","forecasted","forecasting"};
        verbs[60] = new String[]{"forget","forgets","forgot","forgotten","forgetting"};
        verbs[61] = new String[]{"forsake","forsakes","forsook","forsaken","forsaking"};
        verbs[62] = new String[]{"freeze","freezes","froze","frozen","freezing"};

        verbs[63] = new String[]{"geld","gelds","gelded","gelt","gelding"};
        verbs[64] = new String[]{"get","gets","got","gotten", "getting"};
        verbs[65] = new String[]{"gild","gilds","gilded","gilt","gilding"};
        verbs[66] = new String[]{"give","gives","gave","given","giving"};
        verbs[67] = new String[]{"gnaw","gnaws","gnawed","gnawn","gnawing"};
        verbs[68] = new String[]{"go","goes","went","gone","going"};
        verbs[69] = new String[]{"grind","grinds","ground","grinding"};
        verbs[70] = new String[]{"grip","grips","gripped","gript","gripping"};
        verbs[71] = new String[]{"grow","grows","grew","grown","growing"};

        verbs[72] = new String[]{"hang","hangs","hung","hanging"};
        verbs[73] = new String[]{"have","has","had","having"};
        verbs[74] = new String[]{"hear","hears","heard","hearing"};
        verbs[75] = new String[]{"heave","heaves","heaved","hove","heaving"};
        verbs[76] = new String[]{"hew","hews","hewed","hewn","hewing"};
        verbs[77] = new String[]{"hide","hides","hidden","hid","hiding"};
        verbs[78] = new String[]{"hit","hits","hitting"};
        verbs[79] = new String[]{"hold","holds","held","holding"};
        verbs[80] = new String[]{"hurt","hurts","hurting"};

        verbs[81] = new String[]{"keep","keeps","kept","keeping"};
        verbs[82] = new String[]{"kneel","kneels","knelt","kneeled","kneeling"};
        verbs[83] = new String[]{"knit","knits","knitted","knitting"};
        verbs[84] = new String[]{"know","knows","knew","known","knowing"};

        verbs[85] = new String[]{"lay","lays","laid","laying"};
        verbs[86] = new String[]{"lead","leads","led","leading"};
        verbs[87] = new String[]{"lean","leans","leant","leaned","leaning"};
        verbs[88] = new String[]{"leap","leaps","leapt","leaped","leaping"};
        verbs[89] = new String[]{"learn","learns","learnt","learned","learning"};
        verbs[90] = new String[]{"leave","leaves","left","leaving"};
        verbs[91] = new String[]{"lend","lends","lent","lending"};
        verbs[92] = new String[]{"let","lets","letting"};
        verbs[93] = new String[]{"lie","lies","lay","lain","laying"};
        verbs[94] = new String[]{"light","lights","lit","lighted","lighting"};
        verbs[95] = new String[]{"lose","loses","lost","losing"};

        verbs[96] = new String[]{"make","makes","made","making"};
        verbs[97] = new String[]{"may", "might"};
        verbs[98] = new String[]{"mean","means", "meant","meaning"};
        verbs[99] = new String[]{"meet","meets","met","meeting"};
        verbs[100] = new String[]{"melt","melts","melted","molten","melting"};
        verbs[101] = new String[]{"mow","mows","mowed","mowen","mowing"};

        verbs[102] = new String[]{"pay","pays","paid","paying"};
        verbs[103] = new String[]{"pen","pens","pent","penned","penning"};
        verbs[104] = new String[]{"plead","pleads","pled","pleaded","pleading"};
        verbs[105] = new String[]{"prove","proves","proved","proven","proving"};
        verbs[106] = new String[]{"put","puts","putting"};

        verbs[107] = new String[]{"quit","quits","quitted","quitting"};

        verbs[108] = new String[]{"read","reads","reading"};
        verbs[109] = new String[]{"rid","rids","ridded","ridding"};
        verbs[110] = new String[]{"ride","rides","rode","ridden","riding"};
        verbs[111] = new String[]{"ring","rings","rang","rung","ringing"};
        verbs[112] = new String[]{"rise","rises","rose","risen","rising"};
        verbs[113] = new String[]{"run","runs","ran","running"};

        verbs[114] = new String[]{"say","says","said","saying"};
        verbs[115] = new String[]{"see","sees","saw","seen","seeing"};
        verbs[116] = new String[]{"seek","seeks","sought","seeking"};
        verbs[117] = new String[]{"sell","sells","sold","selling"};
        verbs[118] = new String[]{"send","sends","sent","sending"};
        verbs[119] = new String[]{"set","sets","setting"};
        verbs[120] = new String[]{"sew","sews","sewn","sewed","sewing"};
        verbs[121] = new String[]{"shake","shakes","shook","shaken","shaking"};
        verbs[122] = new String[]{"shall","should"};
        verbs[123] = new String[]{"shear","shears","sheared","shorn","shearing"};
        verbs[124] = new String[]{"shed","sheds","shedding"};
        verbs[125] = new String[]{"shine","shines","shones","shining"};
        verbs[126] = new String[]{"shoe","shoes","shod","shoed","shoing"};
        verbs[127] = new String[]{"shoot","shoots","shot","shooting"};
        verbs[128] = new String[]{"show","shows","showed","shown","showing"};
        verbs[129] = new String[]{"shred","shreds","shredded","shredding"};
        verbs[130] = new String[]{"shrink","shrinks","shrank","shrinking"};
        verbs[131] = new String[]{"shut","shuts","shutting"};
        verbs[132] = new String[]{"sing","sings","sang","sung","singing"};
        verbs[133] = new String[]{"sink","sinks","sank","sunk","sinking"};
        verbs[134] = new String[]{"sit","sits","sat","sitting"};
        verbs[135] = new String[]{"slay","slays","slew","slain","slaying"};
        verbs[136] = new String[]{"sleep","sleeps","slept","sleeping"};
        verbs[137] = new String[]{"slide","slides","slid","sliding"};
        verbs[138] = new String[]{"sling","slings","slang","slung","slinging"};
        verbs[139] = new String[]{"slink","slinks","slunk","slinking"};
        verbs[140] = new String[]{"slit","slits","slitting"};
        verbs[141] = new String[]{"smell","smells","smelt","smelled","smelling"};
        verbs[142] = new String[]{"smite","smites","smote","smitten","smiting"};
        verbs[143] = new String[]{"sow","sows","sowed","sowen","sowing"};
        verbs[144] = new String[]{"speak","speaks","spoke","spoken","speaking"};
        verbs[145] = new String[]{"speed","speeds","sped","speeded","speeding"};
        verbs[146] = new String[]{"spell","spells","spelt","spelled","spelling"};
        verbs[147] = new String[]{"spend","spends","spent","spending"};
        verbs[148] = new String[]{"spill","spills","spilt","spilled","spilling"};
        verbs[149] = new String[]{"split","splits","splitting"};
        verbs[150] = new String[]{"spoil","spoils","spoiled","spoilt","spoiling"};
        verbs[151] = new String[]{"spread","spreads","spreading"};
        verbs[152] = new String[]{"spring","springs","sprang","sprung","springing"};
        verbs[153] = new String[]{"stand","stands","stood","standing"};
        verbs[154] = new String[]{"steal","steals","stole","stolen","stealing"};
        verbs[155] = new String[]{"stick","sticks","stuck","sticking"};
        verbs[156] = new String[]{"sting","stings","stung","stinging"};
        verbs[157] = new String[]{"stink","stinks","stank","stunk","stinking"};
        verbs[158] = new String[]{"stride","strides","strode","stridden","striding"};
        verbs[159] = new String[]{"strike","strikes","struck","striking"};
        verbs[160] = new String[]{"string","strings","strung","stringing"};
        verbs[161] = new String[]{"strive","strives","strove","striven","striving"};
        verbs[162] = new String[]{"swear","swears","swore","sworn","swearing"};
        verbs[163] = new String[]{"sweat","sweats","sweated","sweating"};
        verbs[164] = new String[]{"sweep","sweeps","swept","sweeping"};
        verbs[165] = new String[]{"swell","swells","swelled","swollen","swelling"};
        verbs[166] = new String[]{"swim","swims","swam","swum","swimming"};
        verbs[167] = new String[]{"swing","swings","swung","swinging"};

        verbs[168] = new String[]{"take","takes","took","taken","taking"};
        verbs[169] = new String[]{"teach","teaches","taught","teaching"};
        verbs[170] = new String[]{"tear","tears","tore","torn","tearing"};
        verbs[171] = new String[]{"telecast","telecasts","telecasted","telecasting"};
        verbs[172] = new String[]{"tell","tells","told","telling"};
        verbs[173] = new String[]{"think","thinks","thought","thinking"};
        verbs[174] = new String[]{"throw","throws","threw","thrown","throwing"};
        verbs[175] = new String[]{"thrust","thrusts","thrusting"};
        verbs[176] = new String[]{"tread","treads","trod","trodden","trodding"};

        verbs[177] = new String[]{"understand","understands","understood","understanding"};

        verbs[178] = new String[]{"wake","wakes","woke","waked","woken","waking"};
        verbs[179] = new String[]{"wear","wears","wore","worn","wearing"};
        verbs[180] = new String[]{"weave","weaves","wove","woven","weaving"};
        verbs[181] = new String[]{"wed","weds","wedded","wedding"};
        verbs[182] = new String[]{"weep","weeps","wept","weeping"};
        verbs[183] = new String[]{"win","wins","won","winning"};
        verbs[184] = new String[]{"wind","winds","wound","winding"};
        verbs[185] = new String[]{"wring","wrings","wrung","wringing"};
        verbs[186] = new String[]{"write", "writes","wrote","written","writing"};
        return verbs;
    }

    public String[] createVerb(String word){
        if(word.equals("")){
            return new String[]{""};
        }
        for(String[] irregularVerb : irregularVerbs){
            for(String conjugation : irregularVerb){
                if(word.equalsIgnoreCase(conjugation)){
                    return irregularVerb;
                }
            }
        }
        return createRegularVerb(word);
    }

    private String[] createRegularVerb(String word) {
        int length = word.length();
        if(word.endsWith("ies")){
            return createIesVerb(word);
        }
        if(word.endsWith("ied")){
            return createIedVerb(word);
        }
        if(word.endsWith("ed")){
            return createEdVerb(word);
        }
        if(word.endsWith("es")) {
            return createEsVerb(word);
        }
        if(word.endsWith("s")){
            return createSVerb(word);
        }
        if(word.endsWith("e")){
            return new String[]{word, word+"s", word+"d", word.substring(0,length-1)+"ing"};
        }
        if(word.endsWith("h")||word.endsWith("x")){
            return new String[]{word, word+"es", word+"ed", word+"ing"};
        }
        if(word.endsWith("y") && checkIfConsonant(word.charAt(length-1))){
            return createConsonantYVerb(word);
        }
        if(word.endsWith("ing")){
            return createIngVerb(word);

        }
        return new String[]{word, word+"s", word+"ed",word+"ing", word+word.substring(length-1)+"ed", word+word.substring(length-1)+"ing", word+"e", word+"es"};
    }

    private boolean checkIfConsonant(char letter) {
        return !(letter=='a'||letter=='e'||letter=='i'||letter=='o'||letter=='u');
    }

    private String[] createIesVerb(String word){
        int length = word.length();
        String newBase1 = word.substring(0,length-3);
        String newBase2 = newBase1+"y";
        return new String[]{word, newBase2, newBase1+"ied", newBase2+"ing"};
    }

    private String[] createIedVerb(String word){
        int length = word.length();
        String newBase1 = word.substring(0,length-3);
        String newBase2 = newBase1+"y";
        return new String[]{word, newBase2, newBase1+"ies", newBase2+"ing"};
    }

    private String[] createEsVerb(String word){
        int length = word.length();
        String newBase1 = word.substring(0, length - 1);
        String newBase2 = word.substring(0, length - 2);
        return new String[]{word, word + "es", word + "ed", word + "ing", newBase1, newBase1 + "d", newBase2, newBase2 + "ed", newBase2 + "ing"};
    }

    private String[] createSVerb(String word){
        int length = word.length();
        String newBase = word.substring(0, length-1);
        return new String[]{word, word+"es", newBase, word+"ed", newBase+"ed",word+"ing", newBase+"ing"};
    }

    private String[] createEdVerb(String word){
        int length = word.length();
        String newBase1 = word.substring(0, length - 1);
        String newBase2 = word.substring(0, length - 2);
        return new String[]{word, word + "s", word + "ing", newBase1, newBase1 + "s", newBase2, newBase2 + "s", newBase2.substring(0, length-2) + "ing"};

    }

    private String[] createConsonantYVerb(String word){
        int length = word.length();
        String newBase = word.substring(0, length-1);
        return new String[]{word, newBase+"ied",newBase+"ies",word+"ing"};
    }

    private String[] createIngVerb(String word){
        int length = word.length();
        String newBase = word.substring(0, length-3);
        return createRegularVerb(newBase);
    }
}