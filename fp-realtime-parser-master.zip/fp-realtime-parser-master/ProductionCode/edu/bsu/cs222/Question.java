package edu.bsu.cs222;

public class Question extends Sentence {

    private String[] subject;
    private String[] action;
    private String[] directObject;
    private String questionType;
    private PrepositionalPhrase[] prepositionalPhrases;
    private String sentence;

    public Question(String sentence) {
        this.sentence = sentence;
        String[] splitSentence = sentence.split(" ");
        String firstWord = splitSentence[0];
        if (firstWord.equals("What")) {
            whatParse(splitSentence);
        }
        else if (firstWord.equals("Who")) {
            whoParse(splitSentence);
        }
        else if(firstWord.equals("Did")){
            didParse(splitSentence);
        }

    }

    private void didParse(String[] words) {
        Sentence innerSentence = createInnerSentence(words);
        questionType = "yes or no";
        subject = innerSentence.getSubject();
        action = innerSentence.getAction();
        directObject = innerSentence.getDirectObject();

    }

    private Sentence createInnerSentence(String[] words){
        String tempSentence = "";
        for(int i = 1; i<words.length; i++){
            tempSentence = tempSentence + " "+ words[i];
        }
        tempSentence = tempSentence.trim();
        return new Sentence(tempSentence);
    }

    private void whatParse(String[] words) {
        String[] knownPrepositions = new String[]{"with", "at", "from", "into", "during", "including", "until", "against", "among", "throughout", "despite", "towards", "upon", "to", "in", "for", "on", "by", "about", "like", "through", "over", "before", "between", "after", "since", "without", "under", "within", "along", "following", "across", "behind", "beyond", "plus", "except", "but", "up", "out", "around", "down", "off", "above", "near"};
        int numberOfPrepositionalPhrases = 0;
        prepositionalPhrases = new PrepositionalPhrase[50];
        int wordTypeCount = 0;
        NounBuilder nounBuilder = new NounBuilder();
        VerbBuilder verbBuilder = new VerbBuilder();

        //This may not run through all of the values
        for (int i = 1; i < words.length; i++) {
            String word = words[i];
            if (!(word.equalsIgnoreCase("the") || word.equalsIgnoreCase("a") || word.equalsIgnoreCase("an"))) {
                //Finds and creates prepositional phrases
                for (String preposition : knownPrepositions) {
                    if (word.equalsIgnoreCase(preposition)) {
                        int prepositionalPhraseWordCount = 0;
                        String phrase[] = new String[2];
                        while (prepositionalPhraseWordCount <= 1) {
                            if (word.equalsIgnoreCase("the") || word.equalsIgnoreCase("a") || word.equalsIgnoreCase("an")) {
                                i++;
                                word = words[i];
                            } else {
                                phrase[prepositionalPhraseWordCount] = word;
                                i++;
                                if (i < words.length) {
                                    word = words[i];
                                }
                                prepositionalPhraseWordCount++;
                            }
                        }
                        prepositionalPhrases[numberOfPrepositionalPhrases] = new PrepositionalPhrase(phrase);
                        numberOfPrepositionalPhrases++;
                    }
                }
                if (wordTypeCount == 0) {
                    if (!(word.equalsIgnoreCase("the") || word.equalsIgnoreCase("a") || word.equalsIgnoreCase("an"))) {
                        if(word.equals("did")){
                            i++;
                            word = words[i];
                            if ((word.equalsIgnoreCase("the") || word.equalsIgnoreCase("a") || word.equalsIgnoreCase("an"))) {
                                i++;
                                word = words[i];
                            }
                            subject = nounBuilder.createNoun(word);
                            wordTypeCount++;
                        }
                        else{
                           questionType = "direct object";
                           directObject = new String[]{""};
                           wordTypeCount++;
                        }
                    }
                }
                if (wordTypeCount == 1){
                    if("direct object".equals(questionType)){
                        if(word.equals("did")){
                            i++;
                            word = words[i];
                            if ((word.equalsIgnoreCase("the") || word.equalsIgnoreCase("a") || word.equalsIgnoreCase("an"))) {
                                i++;
                                word = words[i];
                            }
                            subject = nounBuilder.createNoun(word);
                            wordTypeCount++;
                        }
                    }
                    else{
                        if(word.equals("do")){
                            questionType = "action";
                            wordTypeCount++;
                            action = new String[]{""};
                            i++;
                            if(i<words.length){
                                word = words[i];
                                boolean testIfPreposition = false;
                                for(String knownPreposition : knownPrepositions){
                                    if(knownPreposition.equals(word)){
                                        testIfPreposition = true;
                                    }
                                }
                                if(testIfPreposition == true){
                                    i++;
                                    word = words[i];
                                    if ((word.equalsIgnoreCase("the") || word.equalsIgnoreCase("a") || word.equalsIgnoreCase("an"))) {
                                        i++;
                                        word = words[i];
                                    }
                                    directObject = nounBuilder.createNoun(word);
                                    wordTypeCount++;
                                }
                            }
                            else{
                                directObject = new String[]{""};
                                wordTypeCount++;
                            }
                        }
                    }
                }
                if(wordTypeCount==2){
                    i++;
                    word = words[i];
                    action = verbBuilder.createVerb(word);
                    wordTypeCount++;
                }
            }

        }
    }

    private void whoParse(String[] words) {
        String[] knownPrepositions = new String[]{"with", "at", "from", "into", "during", "including", "until", "against", "among", "throughout", "despite", "towards", "upon", "to", "in", "for", "on", "by", "about", "like", "through", "over", "before", "between", "after", "since", "without", "under", "within", "along", "following", "across", "behind", "beyond", "plus", "except", "but", "up", "out", "around", "down", "off", "above", "near"};
        int numberOfPrepositionalPhrases = 0;
        prepositionalPhrases = new PrepositionalPhrase[50];
        int wordTypeCount = 0;
        NounBuilder nounBuilder = new NounBuilder();
        VerbBuilder verbBuilder = new VerbBuilder();

        //This may not run through all of the values
        for (int i = 1; i < words.length; i++) {
            String word = words[i];
            if (!(word.equalsIgnoreCase("the") || word.equalsIgnoreCase("a") || word.equalsIgnoreCase("an"))) {
                //Finds and creates prepositional phrases
                for (String preposition : knownPrepositions) {
                    if (word.equalsIgnoreCase(preposition)) {
                        int prepositionalPhraseWordCount = 0;
                        String phrase[] = new String[2];
                        while (prepositionalPhraseWordCount <= 1) {
                            if (word.equalsIgnoreCase("the") || word.equalsIgnoreCase("a") || word.equalsIgnoreCase("an")) {
                                i++;
                                word = words[i];
                            } else {
                                phrase[prepositionalPhraseWordCount] = word;
                                i++;
                                if (i < words.length) {
                                    word = words[i];
                                }
                                prepositionalPhraseWordCount++;
                            }
                        }
                        prepositionalPhrases[numberOfPrepositionalPhrases] = new PrepositionalPhrase(phrase);
                        numberOfPrepositionalPhrases++;
                    }
                }
                if(wordTypeCount==0){
                    if(word.equals("did")){
                        questionType = "direct object";
                        wordTypeCount++;
                    }
                    else{
                        action = verbBuilder.createVerb(word);
                        wordTypeCount++;
                        questionType = "subject";
                        subject = new String[]{""};
                        wordTypeCount++;
                    }
                }
                else if (wordTypeCount==1){
                    subject = nounBuilder.createNoun(word);
                    wordTypeCount++;
                }
                else if(wordTypeCount == 2){
                    if(questionType.equals("direct object")){
                        action = verbBuilder.createVerb(word);
                        wordTypeCount++;
                    }
                    else if(questionType.equals("subject")){
                        directObject = nounBuilder.createNoun(word);
                        wordTypeCount++;
                    }
                }
            }
        }
        if(directObject == null){
            directObject = new String[]{""};
        }
    }
    public String[] getSubject(){
        return subject;
    }

    public String[] getAction(){
        return action;
    }

    public String[] getDirectObject(){
        return directObject;
    }

    public String getSentence() { return sentence; }

    public PrepositionalPhrase[] getPrepositionalPhrases(){return prepositionalPhrases; }

    public String getQuestionType(){return questionType;}

}